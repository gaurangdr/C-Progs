#include<stdio.h>
int inr=INR;
#define INR 10
int main()
{
	printf("INR is first %d and after is %d\n",inr,INR);
	return 0;
}
