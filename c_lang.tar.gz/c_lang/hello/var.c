#include<stdio.h>

int glob_var1;

int glob_vari_ini = 10;

int main()
{

	int local_var1;
	int local_var2=20;
	return 0;
}
