#include<stdio.h>
int main()
{
	int a;
	a=10;
	printf("A is %d\n",a);
	return 0;
}
