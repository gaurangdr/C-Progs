#inlcude<stdio.h>
#include<stdlib.h>
int main()
{
	sigset_t s1,s2;
	char buf1[100];
	struct sigaction act1,act2;
	int 
