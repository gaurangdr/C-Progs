#include<stdio.h>
int main()
{
	enum dir
	{
		north,
		south,
		west,
		east,
	};
	printf("%d\n",east);
	return 0;
}
