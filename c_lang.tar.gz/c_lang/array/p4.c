#include<assert.h>
#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	assert(a>10);
	printf("A is %d\n",a);
	return 0;
}
