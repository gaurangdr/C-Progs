#include<stdio.h>
int main()
{
	volatile int a=10;
	return 0;
}
