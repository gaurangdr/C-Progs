#include<stdio.h>
int main()
{
	int n,ans=0,i=1,rem;
	scanf("%d",&n);
	while(n)
	{
		rem=n%2;
		ans=ans+rem*i;
		i=i*10;
		n/=2;
	}
	printf("ans is %d\n",ans);	
	return 0;
}	
