#include<stdio.h>
int main()
{
	char *s1="Hello";
	strrev(s1);
	printf("%s\n",s1);
	return 0;
}
