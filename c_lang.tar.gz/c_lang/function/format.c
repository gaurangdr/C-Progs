#include<stdio.h>
int main()
{
	int n,dec,bin;
	scanf("%d",&dec);
	bin=con(n);
	printf("%d==%d\n",dec,bin);
	return 0;
}
int con(int n)
{
	int bin;
	if(n/2==0)
		return 0;
	bin=(n%2)*(10^+bin
