#include<stdio.h>
int main()
{
	int n, sum=0;
	scanf("%d",&n);
	sum=add(n);
	printf("Sum %d\n",sum);
	return 0;
}
