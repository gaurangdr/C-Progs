#include<stdio.h>
int a;
int b[2]={1,2};
void dis1(void)
{
	printf("Hello from other\n");
	return;
}
