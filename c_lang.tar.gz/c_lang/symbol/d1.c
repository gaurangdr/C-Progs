#include<stdio.h>
extern int b[];
int main()
{
	printf(" b is %d and %d\n",b[0],b[1]);
	return 0;
}
