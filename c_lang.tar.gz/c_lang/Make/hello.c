#include<stdio.h>
int main()
{
	printf("Hello India\n");
	return 0;
}
