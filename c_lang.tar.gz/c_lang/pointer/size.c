#include<stdio.h>
#define NU 0L
int main()
{
	int a;
	printf("size %d\n",sizeof(NU));
	return 0;
}
