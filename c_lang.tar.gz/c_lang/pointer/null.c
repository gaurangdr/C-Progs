#include<stdio.h>
int main()
{
	int *nptr=NULL;
	int a;
//	a=*nptr;
	if(NULL==0)
	{
		printf("zeor\n");
		printf("size od NULL %d\n",sizeof(NULL));
	}
//	*nptr=10;
//	printf("a is %d\n",a);
	return 0;
}
