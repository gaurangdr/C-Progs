#include<stdio.h>
int data=10;

int in_data(void)
{
	int a;
	scanf("%d",&a);
	return a;
}
