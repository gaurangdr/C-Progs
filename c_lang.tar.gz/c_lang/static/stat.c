#include<stdio.h>
static void dis(void);
int main()
{
	dis();
	return 0;
}
static void dis()
{
	printf("Hi\n");
	return;
}
