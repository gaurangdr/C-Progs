#include<stdio.h>
int main()
{
	int a,b,c=10;
	float f;
//	f=5f;	// produce compiler time error
	f=5.5f;
	a=b=c;
	return 0;}
