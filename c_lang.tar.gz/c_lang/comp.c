#include<stdio.h>
#include<math.h>
int a= pow(2,3);
//int b=pow(2,a);
int main()
{
	printf("%d\n",a);
	return 0;
}
